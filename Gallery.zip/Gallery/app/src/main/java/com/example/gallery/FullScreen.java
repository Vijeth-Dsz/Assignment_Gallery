package com.example.gallery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;

public class FullScreen extends AppCompatActivity {
ImageView imageView;
Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_screen);
        button=findViewById(R.id.btndelete);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int id = imageView.getId();
                Log.i("start", "BEGIN_DELETE");
                String myPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/My Directory/";
               File file= new File(myPath + imageView.getDrawable());

                if(file.exists()){
                    file.delete();
                }
                Log.i("end", "END_DELETE");

                imageView.setImageDrawable(null);

                Toast.makeText(FullScreen.this,"Delete Successfully", Toast.LENGTH_SHORT).show();

            }
        });
        imageView=findViewById(R.id.image_view);
        getSupportActionBar().hide();
        getSupportActionBar().setTitle("Full screen Image");
        Intent i=getIntent();
        int position=i.getExtras().getInt("id");
        imageAdapter imageAdapter=new imageAdapter(this);

        imageView.setImageResource(imageAdapter.imgArray[position]);
    }
}